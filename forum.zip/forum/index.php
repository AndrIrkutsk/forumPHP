<?php
	session_start();
	ini_set('error_reporting', E_ALL);
	
	require_once('script/config.php');
	require_once('script/dbconnect.php');
	require_once('script/script.php');
	//require_once('script/profile.php');
	
	// сохранение последней отправленной записи
	// если создана тема форума/ вставка в базу
	$result = array();
	$result['error'] = '';
	$namePost="";
	$opisPost="";

	if(isset($_SESSION["username"])) $nameUser=$_SESSION["username"]; // инициализация если пользователь авторизован
		else $nameUser="Anonymous"; // инициализация если пользователь не авторизован


	if(isset($_POST["subPost"])){ // добавление поста
		
		$namePost = stripcslashes(strip_tags($_POST["namePost"]));
		$opisPost = stripcslashes(strip_tags($_POST["opisPost"]));
		$nameUser = stripcslashes(strip_tags($_POST["nameUser"])); // перезапись если пользователь ввел имя
		if(empty($nameUser)) $nameUser="Anonymous"; 
		
		$date = date('Y-m-d H:i:s');
		
		if(strlen($namePost) < 1){
			$result['error'] .= '<p style=color:red;>Введите название поста!</p>';
		}

		if(strlen($opisPost) < 1){
			$result['error'] .= '<p style=color:red;>Введите описание поста!</p>';
		}

		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $namePost)) $flag = true;
		if(preg_match_all($pattern, $opisPost)) $flag = true;
		if(preg_match_all($pattern, $nameUser)) $flag = true;

		if (!$flag){ 
			if(empty($result['error'])){ // добавление поста
				if(isset($_SESSION["userid"])){
					$res = mysqli_query($link, "INSERT INTO `nametheme` SET `iduser` = '" .$_SESSION["userid"]. "', `nameuser` = '" . $nameUser. "', `name` = '" . $namePost. "', `opis` = '" . $opisPost. "', `date` = '" . $date. "'");
				}else{
					$res = mysqli_query($link, "INSERT INTO `nametheme` SET `nameuser` = '" . $nameUser. "', `name` = '" . $namePost. "', `opis` = '" . $opisPost. "', `date` = '" . $date. "'");
				}
				if($res){
					header("Location: http://forum/");
					exit;
				}
			}
		}else{
			$result['error'] .= '<p style=color:red;>Удалите спец.символы!</p>';
		}
	}

	$arrs = get_page($link);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forum</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/form.css" rel="stylesheet">
	<style type="text/css">
		/*new pagi*/
		.num {
		  display: none;
		}
		.paginator {
		  line-height: 150%;
		}
		.paginator > span {
		  display: inline-block;
		  margin-right: 10px;
		  cursor: pointer;
		}
		.paginator_active {
		  color: red;
		}
	</style>
  </head>
  <body>
  	<section class="container">
	  <div class="row">
		<div class="col-md-12">

			<div class="bodyforum"></div>
			
			<div class="row">
			  <div class="col-md-10 col-md-offset-1">

				<div class="searchWrap">
					<div class="searchForm">
						<form method="POST">
							<!-- <input type="text" x-webkit-speech> -->
							<input type="text" id="searchPost" name="textSearch" placeholder="Введите текст" required>
							<p id=delresinput></p>
						</form>
						<div id="errDivWrap">
							<span id="spanMess" style="color: #e08e36"></span>
							<span id="errorChar" style="color:#ff1515;font-size:16px"></span>
						</div>
					</div>
				</div>

			  	<div class="displayError">
			  		<?php print_r($result['error']); ?>
			  	</div>
				<table class="tableForum" >
					<thead>
						<tr>
							<th class="tableTdId">ID</th>
							<th class="tableTdZero">Имя</th>
							<th class="tableTdFirst">Название поста</th>
							<th class="tableTdSecond">Краткое описание</th>
							<th class="tableTdThirth">Время добавления</th>
						</tr>
					</thead>
					<tbody id="bodyPost">
						<?php foreach ($arrs as $value) { ?>
							<tr>
							   <td><?= $value['id']; ?></td>
							   <td><?= $value['nameuser']; ?></td>
							   <td><a href="http://forum/script/posts.php?postid=<?= $value['id']; ?>"><?= splitTextName($value['name']); ?> </a></td>
							   <td><?= splitTextOpis($value['opis']); ?></td>
							   <td class=dateRow><?= transformDate($value['date']); ?></td>
						    </tr>
						<?php } ?>
					</tbody>
				</table>
				<div class="pagiWrap">
					<?php print(print_page($link)); ?>
				</div>			
				<div class="paginator" onclick="pagination(event)"></div>

				<div class="col-md-8 col-md-offset-2">
					
					<h2 class="headCreatePost">Создать пост</h2>
					<!-- Button trigger modal -->
					<button id="butProf" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modalLogin">
				        Логин / Авторизация
				    </button>
				    <!-- Modal -->
					<div class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					        <h4 class="modal-title" id="myModalLabel">
						        Пройти авторизацию
						        <a href="#modalReg">
		                            <button type="button" class="btn btn-info" id="createakk" >
		                                Создать новый аккаунт
		                            </button>
		                        </a>
						    </h4>

					      </div>
					      <div class="modal-body contact_form">
                            <h2 class="headCreatePost" id="headLoginH2">Войти в систему</h2>
                            
                            <div class="wrapLogin">
	                            <div class="field field-login">
	                                <input type="text" name="login" id="enterLogin" placeholder="Логин" />
	                            </div>
	                            <div class="field field-password">
	                                <input type="password" name="password" id="enterPass" placeholder="Пароль" />
	                            </div>
	                            <div>
	                                <button class="button entLog" id="subEntLogin" onclick="auth.login(this);return false;">Войти</button>
	                            </div>
	                            <div class="errMessLog"></div>
	                            <div class="errMessLogBack"></div>
	                            <div class="errLogSucc"></div>
		                    </div>

					      </div>
					    </div>
					  </div>
					</div>

					<div class="modal fade" id="modalReg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					        <h4 class="modal-title" id="myModalLabel">
						        Пройти Регистрацию
						        <a href="#modalLogin">
		                            <button type="button" class="btn btn-info" id="createakk" >
		                                Уже есть учётная запись?
		                            </button>
		                        </a>
						    </h4>
					      </div>
					      <div class="modal-body">
							<div class="wrapLogin">
                                <h2 class="headCreatePost" id="headLoginH2">Регистрация пользователя</h2>
                                <div class="field field-login-reg">
                                    <input type="text" name="username" id="username" placeholder="Ваш Никнейм" maxlength="70" />
                                </div>
                                <div class="field field-login-reg">
                                    <input type="text" name="useremail" id="useremail" placeholder="Ваш Email" maxlength="100" required />
                                </div>
                                <div class="field field-login-reg">
                                    <input type="text" name="login" id="login" placeholder="Логин" maxlength="80" />
                                </div>
                                <div class="field field-password-reg">
                                    <input type="password" name="password" id="password" placeholder="Введите Пароль" maxlength="100" />
                                </div>
                                <div class="field field-password-reg">
                                    <input type="password" name="password_conf" id="password_conf" placeholder="Повторите Пароль" maxlength="100" />
                                </div>
                                <div class="panel-group" id="accordion">
								  <div class="panel panel-default">
								    <div class="panel-heading">
								      <h4 class="panel-title">
						                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
						                  <i class="fa fa-user" aria-hidden="true"></i>
						                  Аватарка
						                </a>
						              </h4>
								    </div>
								    <div id="collapseOne" class="panel-collapse collapse">
								      <div class="panel-body" id="myreceivgift">

										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="1" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-1.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="2" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-2.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="3" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-3.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="4" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-4.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="5" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-5.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="6" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-6.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="7" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-7.png">
											</i>
										  </label>
										</div>
										<div id="thumbs">	  
										  <label class="jRadioImage thumb-radio-image loading">
											<input type="radio" value="8" name="choose_image" tabindex="-1">
											<i class="thumb-image">
												<img src="img/avatar-8.png">
											</i>
										  </label>
										</div>

								      </div>
								    </div>
								  </div>
								</div>
                                <div>
                                    <button class="button" id="subEntReg" onclick="auth.registration(this);return false;">Зарегистрироваться</button>
                                </div>
                                <div class="errMess"></div>
                                <div class="errMessBack"></div>
                                <div class="errSucc"></div>
                            </div>

                            <!-- <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">
								<legend>Test From</legend>
								<label for="name">Name:</label><input id="name" name="name" value="" type="text">
								<label for="email">Email:</label><input id="email" name="email" value="" type="text">
								<input value="Send" type="submit">
							</form> -->
                            
					      </div>
					    </div>
					  </div>
					</div>

					<form action="/" method="POST" class="contact_form">
						<input type="text" id="nameUserSendPost" class=nameUser name="nameUser" value=<?= $nameUser; ?> placeholder="Введите Своё Имя" />
						<input type="text" id="namePost" name="namePost" placeholder="Введите название темы" />
						<textarea rows="3" id="opisPost" class="textEnterMain" name="opisPost" placeholder="Описание обращения"></textarea>
						<input type="submit" id="subPost" name="subPost" value="Отправить" />
					</form>			
				
				</div>
			  
			  </div>
			</div>
			
	    </div>
	  </div>
  	</section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">

	    $('input[name="choose_image"]:radio').change(function(){
 			//var container = $("#thumbs");
 			var parent = $(this).closest('.jRadioImage');

 			$('.jRadioImage').not(parent).removeClass('active');
 			parent.addClass('active');
 		});

    </script>
  </body>
</html>