function Auth(){
	this.nickname;
	this.password;
}

Auth.prototype.login = function(button){
	var button = $(button);
	
	var login = $("#enterLogin").val();
	var password = $("#enterPass").val();

	var error = [];

	if(login == ""){
		error.push("<p class='errorMessage error_logo'>Введите логин!</p>");
	}else if(login.length > 0 && login.length < 2){
		error.push("<p class='errorMessage error_logo'>Введите логин не менее 2-х символов</p>");
	}else{
		$(".errMessLog").find('p.error_logo').text('');
	}

	if(password.length < 3){
		error.push("<p class='errorMessage error_pass_logo'>Введите пароль не менее 3-и символов</p>");
	}else{
		$(".errMessLog").find('p.error_pass_logo').text('');
	}

	if(error.length == 0){

		$.ajax({
			type: 'POST',
			url: 'script/profile.php?requestLogin',
			// для ответа сервером 'json'-форматом
			//dataType: 'json',
			// выполняется во время отправки запроса
			//beforeSend: function(){
			//	button.addClass('loading');
			//},
			data: { "login": login, "password": password },
			
			success: function(result){
				//console.log(result);
				//button.removeClass('loading');
				
				var massStr = "";

				if(result['error'] != undefined){		
					
					for (var key in result['error']) {
						massStr += result['error'][key];

						if(key == 'login') $('#enterLogin').val('');
						if(key == 'password') $('#enterPass').val('');
					}
					
					$('.errMessLogBack').html(massStr);
				}else{
					$('.errMessLogBack').html('');
				}

				if(result['succ'] != undefined){	
					$('.errLogSucc').html(result['succ']['luck']);
					setTimeout(function(){
						location.reload();
					}, 4000);
				}
			}
		});
	}else{
		$(".errMessLog").html(error.join(""));
		$(".errMessLogBack").html('');
	}
};

Auth.prototype.registration = function(button){
	var button = $(button);

	var userName = $("#username").val();
	var useremail = $("#useremail").val();
	var login = $("#login").val();
	var password = $("#password").val();
	var password_conf = $("#password_conf").val();

	var img = $('input[name="choose_image"]:checked').val(); // val img - 1-8
//alert(img);
	/**********************************************/
	var error = [];

	if(userName == ""){
		error.push("<p class='errorMessage error_user'>Введите Никнейм</p>");
	}else if(userName.length > 0 && userName.length < 2){
		error.push("<p class='errorMessage error_user'>Никнейм должен быть не менее 2-х символов</p>");
	}else{
		$(".errMess").find('p.error_user').text('');
	}

	// проверка емэйл
	var pattern = /[\w\.-]*@[\w-]+[.][\w-]+/i;
	var result = useremail.match(pattern);
	if(!result){
		error.push("<p class='errorMessage error_email'>Email не корректен</p>");
	}else{
		$(".errMess").find('p.error_email').text('');
	}

	if(login.length < 5){
		error.push("<p class='errorMessage error_login'>Логин должен быть не менее 5-и символов</p>");
	}else{
		$(".errMess").find('p.error_login').text('');
	}
	if(password.length < 5){
		error.push("<p class='errorMessage error_pass'>Введите пароль не менее 5-и символов</p>");
	}else{
		$(".errMess").find('p.error_pass').text('');
	}
	if(password !== password_conf){
		error.push("<p class='errorMessage error_pass_conf'>Пароли не совпадают</p>");
	}else{
		$(".errMess").find('p.error_pass_conf').text('');
	}
	/**********************************************/

	if(error.length == 0){	

		$.ajax({
			type: 'POST',
			url: "script/profile.php?registration",
			data: { "userName": userName, "useremail": useremail, "login": login, "password": password, "password_conf": password_conf, "img": img },
			
			success: function(result){
				//console.log(result);

				var massStr = "";

				if(result['error'] != undefined){		
					
					for (var key in result['error']) {
						massStr += result['error'][key];

						if(key == 'username') $('#username').val('');
						if(key == 'email') $('#useremail').val('');
					}
					
					$('.errMessBack').html(massStr);
				}else{
					$('.errMessBack').html('');
				}

				if(result['succ'] != undefined){
					
					$('.errSucc').html(result['succ']['luck']);

					var date = new Date(new Date().getTime() + 3600 * 1000);
					document.cookie = "forum_cookieMy="+result.success.forum_hash+"; path=/; expires=" + date.toUTCString();
					//window.location.href = "/6-autorization(ajax_cookie)/";
				}
			}
		});
	}else{
		$(".errMess").html(error.join(""));
		$(".errMessBack").html('');
	}
};

var auth = new Auth();

// получение объекта выделения
function getSelectedText(){
    var text = '';
    if (window.getSelection) {
        text = window.getSelection().toString();
    } else if (document.selection) {
        text = document.selection.createRange().text;
    }
    return text;
}

function searchCheck(inputval){

	var arrErrSimbol = checkInput(inputval); // массив ошибок
	if(arrErrSimbol.length){
		$("#spanMess").html("Удалите из поля ввода спец.символ ");
		$("#errorChar").html(arrErrSimbol.join(' ')); // обновление показа запрещ.символов
		
		return false;
	}else{
		$("#spanMess").html('');
		$("#errorChar").html('');
	}
	return true;
}

/**
*	valInput - значение поля инпут
**/
function checkInput(valInput){
	var arrErr = [];

	arrErr.length = 0; // обнуление массива
	for (var i = 0; i < valInput.length; i++) { // новый перебор строки с учетом удаленного символа
    	if ( /[!,#,$,%,^,&,*,(,),[,\],{,},?,>,<,",',№,;,:,=,`,~,|,+,\,]/.test(valInput[i]) ) { // новый поиск спец.символов
	    	arrErr.push(valInput[i]); // новое формирование массива запрещ символов
		}
	}
	return arrErr;
}

$(document).ready(function(){

	var url=location.href;
	var fr=url.split("&");
	var succ=fr[1];
	if(succ == "succ") $("#errorMess").html('');

	// отключение распознавание речи
	if (document.createElement('input').webkitSpeech !== undefined) {
		// Отключить
		document.webkitSpeech = false;
	}

	// document.forms[0].oncontextmenu = function (){return false}; // блокировка контекстного меню первой формы страницы

	var flagSearch=false, input;
	// Проверка поля ввода
	// 33-46, 58-63, 91-94, 96, 123-126 - cpec.simbol
	$("#searchPost").keyup(function(event) {
	    var key = event.key; // const {key} = event; ES6+ // event.keyCode - code

	    lenStr = $("#searchPost").val();
	    if(lenStr.length >= 1){
	    	$("#delresinput").html("<img src='img/close.png' onclick='cleanInput()'>");
	    }else{
	    	location.reload(); // перезагрузка стр - очистка поля инпут, убрать крестик в инпут, заново вывести посты
	    }

	    if(key === "Enter"){
	    	return false;
	    }else{
	    	input = $("#searchPost").val();
		    if ( /[!,#,$,%,^,&,*,(,),[,\],{,},?,>,<,",',№,;,:,=,`,~,|,+,\,]/.test(key) ) { // проверка каждого введенного символа
		    	$("#spanMess").html("Удалите из поля ввода спец.символ ");
		    	$("#errorChar").append(key + " "); // показать запрещенный символ
			}else{

				input = $("#searchPost").val(); // берем значение поля
				flagSearch = searchCheck(input); // true если строка чиста

			    if (key === "Backspace") { // если нажата клавиша "удалить символ"
			    	input = $("#searchPost").val(); // заново берем значение поля					
					flagSearch = searchCheck(input); // true если строка чиста 
			    }
			    if (key === "Delete" || key === "Control") {
					input = $("#searchPost").val(); // заново берем значение поля
					flagSearch = searchCheck(input); // true если строка чиста
			    }

			    // console.log(flagSearch);
			    if(flagSearch && input.trim().length > 1){ // если нет спец.символов, пробелов в строке с двух сторон, и символов 2 и более
			    	
			    	$.ajax({
						type: 'POST',
						url: "script/profile.php?searchpost",
						data: { "searchitem": input },
						
						success: function(result){
							if(result['error'] != undefined){	

								var massStr;

								for (var key in result['error']) {
									massStr += result['error'][key];
								}

								$('#spanMess').html(massStr);
							}else{
								$('#spanMess').html('');
								$('#bodyPost').html(result);
								$('.pagiWrap').html('');

								// pagination
								// to do js upload ajax pagin
								var script = document.createElement("script");
								script.type = "text/javascript";
								script.src = "js/ajax_pagin.js";
								document.body.appendChild(script);
							}
						}
					});

			    }
			}
	    }
	});

	
	// вылавливание вводимого значения
	// [33-46, 58-63, 91-94, 96, 123-126]
	/*var solve = true;
		if( obj >= 33 && obj <= 46 || 
			obj >= 58 && obj <= 63 || 
			obj >= 91 && obj <= 94 || 
			obj == 96 || obj == 8470 ||
			obj >= 123 && obj <= 126){ solve=false; } */
	/*


	// вылавливание вводимого значения
	/* VARIANT-1 on jQuery */
	/*jQuery("input#test_input").on('input', function () {
	    var $valInput = jQuery(this).val(); console.log($valInput);
	    jQuery("div#test_input_get_content").text($valInput);
	});*/

	// вылавливание вводимого значения
	/* VARIANT-2 on jQuery */
	/*jQuery("input#searchPost").keyup(function(){
	   var $valInput = jQuery(this).val(); console.log($valInput);
	   jQuery("div#test_input_get_content").text($valInput);
	});*/


	$("#username, #nameUserSendPost, #namePost, #opisPost, #enterLogin, #enterPass, "
		+ "#useremail, #login, #password, #password_conf").keypress(function(eventObject){
	//  alert("Вы ввели символ с клавиатуры. Его код равен " + eventObject.which);
	  obj = eventObject.which;
	  var solve = false;
	  // obj >= 1072 && obj <= 1103 || obj == 105 - kirillyc small
	  if(obj >= 65 && obj <= 90 || obj >= 97 && obj <= 122 ) solve=true;
	  if(obj >= 48 && obj <= 57 || obj == 44 || obj == 46 || obj == 47 || obj == 64 || obj == 32 || obj == 105 
	  	|| obj >= 1040 && obj <= 1103 || obj == 1025 || obj == 1105) return true; // cirillyc
	  return solve;
	});

	// переключение модали между друг другом по клику на кнопке
	var four_modal = function(id_modal_1,id_modal_2) {
	    var show_modal_2 = false;
	    $('a[href="' + id_modal_2 + '"]').click(function(e) {
	      e.preventDefault();
	      show_modal_2 = true;
	      $(id_modal_1).modal('hide');
	    });
	    $(id_modal_1).on('hidden.bs.modal', function (e) {
	      if (show_modal_2) {
	        show_modal_2 = false;
	        $(id_modal_2).modal('show');
	      }
	    })
	}('#modalLogin', '#modalReg');

	// переключение модали между друг другом по клику на кнопке
	var five_modal = function(id_modal_1,id_modal_2) {
	    var show_modal_2 = false;
	    $('a[href="' + id_modal_2 + '"]').click(function(e) {
	      e.preventDefault();
	      show_modal_2 = true;
	      $(id_modal_1).modal('hide');
	    });
	    $(id_modal_1).on('hidden.bs.modal', function (e) {
	      if (show_modal_2) {
	        show_modal_2 = false;
	        $(id_modal_2).modal('show');
	      }
	    })
	}('#modalReg', '#modalLogin');

});

function cleanInput(){
	location.reload();
}