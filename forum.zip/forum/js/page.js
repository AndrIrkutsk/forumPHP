 window.onload = function() {
	//$('#createFilter').on('show.bs.modal', function (e) {});
	$("#userOtvet, #textOtvet, #userNam, #mainOtv").keypress(function(eventObject){
	  //alert("Вы ввели символ с клавиатуры. Его код равен " + eventObject.which);
	  obj = eventObject.which;
	  var solve = false;
	  // obj >= 1072 && obj <= 1103 || obj == 105 - kirillyc small
	  if(obj >= 65 && obj <= 90 || obj >= 97 && obj <= 122 || obj >= 44 && obj <= 46 || obj == 33 || obj == 63 || obj == 95) solve=true;
	  if(obj >= 48 && obj <= 57 || obj == 44 || obj == 46 || obj == 47 || obj == 64 || obj == 32 || obj == 105 
	  	|| obj >= 1040 && obj <= 1103 || obj == 1025 || obj == 1105) return true; // cirillyc
	  return solve;
	});
	var lenli = $("#chatWrap li").length;
	if(lenli > 30){
		document.getElementById("viewport").style.height = "700px";
	}else if(lenli > 10){
		document.getElementById("viewport").style.height = "300px";
	}else{
		document.getElementById("viewport").style.height = "0";
	}
};


function showvloshen(e){
	// динамическая передача айди в модальное окно
	$("#hid_id").val( $( e ).parent().parent().parent().attr('data-id') );
}
function showvloshenotv(e){
	// динамическая передача айди в модальное окно
	$("#hid_id").val( $( e ).parent().parent().parent().attr('data-id') );
	$("#hid_pos").val( $( e ).parent().parent().parent().attr('data-pos') );
}

function enterotvet(){
	let idpost = $("#hid_id").val();
	let userOtvet = $("#userOtvet").val();
	let textOtvet = $("#textOtvet").val();
	var error = [];

	if(idpost == ""){
		error.push("<p class='errorMessage error_id'>Что-то пошло не так!</p>");
	}else{
		$("#errorOtvet").find('p.error_id').text('');
	}

	if(userOtvet == ""){
		error.push("<p class='errorMessage error_notname'>Введите Имя!</p>");
	}else if(userOtvet.length < 2){
		error.push("<p class='errorMessage error_user'>Введите Имя не менее 2-х символов</p>");
	}else{
		$("#errorOtvet").find('p.error_notname').text('');
		$("#errorOtvet").find('p.error_user').text('');
	}

	if(textOtvet.length < 2){
		error.push("<p class='errorMessage error_opis'>Введите Описание не менее 2-х символов</p>");
	}else{
		$("#errorOtvet").find('p.error_opis').text('');
	}

	if(error.length == 0){
		$.ajax({
			type: 'POST',
			url: 'profile.php?otvetpost',
			data: { "idpost": idpost, "userOtvet": userOtvet, "textOtvet": textOtvet },
			
			success: function(result){				
				
				var massStr = "";
				if(result['error'] != undefined){	
					for (var key in result['error']) {
						massStr += result['error'][key];
					}				
					$('.errorOtvetBack').html(massStr);
				}else{
					$('.errorOtvetBack').html('');
				}

				if(result['succ'] != undefined){	
					$('.otvetBackSucc').html(result['succ']['luck']);
					setTimeout(function(){
						location.reload();
					}, 1000);
				}
			}
		});
	}else{
		$("#errorOtvet").html(error.join(""));
	}
}

function enterotvetnaotvet(){
	let idpost = $("#hid_id").val();
	let hid_pos = $("#hid_pos").val();
	let userOtvet = $("#userOtvetNaOtvet").val();
	let textOtvet = $("#textOtvetNaOtvet").val();
	var error = [];

	if(idpost == ""){
		error.push("<p class='errorMessage error_id'>Что-то пошло не так!</p>");
	}else{
		$("#errorOtvetNaOtv").find('p.error_id').text('');
	}

	if(userOtvet == ""){
		error.push("<p class='errorMessage error_notname'>Введите Имя!</p>");
	}else if(userOtvet.length < 2){
		error.push("<p class='errorMessage error_user'>Введите Имя не менее 2-х символов</p>");
	}else{
		$("#errorOtvetNaOtv").find('p.error_notname').text('');
		$("#errorOtvetNaOtv").find('p.error_user').text('');
	}

	if(textOtvet.length < 2){
		error.push("<p class='errorMessage error_opis'>Введите Описание не менее 2-х символов</p>");
	}else{
		$("#errorOtvetNaOtv").find('p.error_opis').text('');
	}

	if(error.length == 0){
		$.ajax({
			type: 'POST',
			url: 'profile.php?otvetpostotvet',
			data: { "idpost": idpost, "hidpos": hid_pos, "userOtvet": userOtvet, "textOtvet": textOtvet },
			
			success: function(result){				
				
				var massStr = "";
				if(result['error'] != undefined){	
					for (var key in result['error']) {
						massStr += result['error'][key];
					}				
					$('.errorOtvetBackNaOtv').html(massStr);
				}else{
					$('.errorOtvetBackNaOtv').html('');
				}

				if(result['succ'] != undefined){	
					$('.otvetBackSuccNaOtv').html(result['succ']['luck']);
					setTimeout(function(){
						location.reload();
					}, 1000);
				}
			}
		});
	}else{
		$("#errorOtvetNaOtv").html(error.join(""));
	}
}