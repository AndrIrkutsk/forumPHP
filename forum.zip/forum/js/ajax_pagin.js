var count = $("#bodyPost > tr").length; //всего записей
var cnt = 10; //сколько отображаем сначала
var cnt_page = Math.ceil(count / cnt); //кол-во страниц

//выводим список страниц
var paginator = document.querySelector(".paginator");

var page = "";

// Ссылка на первую страницу <<
if(cnt_page > 2) page += "<span id=\"leftTwo\">&lt;&lt; ... </span>";
// Выводим ссылку "Назад", если это не первая страница <
if(cnt_page > 1) page += "<span id=\"leftOne\">&lt; ... </span>"; 

for (var i = 0; i < cnt_page; i++) {
  if(i < 5){
    page += "<span class=\"numPagi\" data-page=" + i * cnt + " id=\"page" + (i + 1) + "\">" + (i + 1) + "</span>";
  }else{
    page += "<span class=\"numPagi\" style=\"display: none;\" data-page=" + i * cnt + " id=\"page" + (i + 1) + "\">" + (i + 1) + "</span>";
  }
}

if(cnt_page > 1) page += "<span id=\"rightOne\"> ... &gt;</span>"; // >
if(cnt_page > 2) page += "<span id=\"rightTwo\"> ... &gt;&gt;</span>"; // >>

if(cnt_page > 1)
  paginator.innerHTML = page;
else
  paginator.innerHTML = '';

//выводим первые записи {cnt}
var div_num = document.querySelectorAll("#bodyPost > tr");
//alert(div_num);
for (var i = 0; i < div_num.length; i++) {
  if (i < cnt) {
    div_num[i].style.display = "table-row";
  }
}

var main_page = document.getElementById("page1");
if(main_page) main_page.classList.add("paginator_active");


//листаем
function pagination(event) {
	
  var e = event || window.event;
  var target = e.target;
  var id = target.id;

 	if (target.tagName.toLowerCase() != "span") return;
  
  var div_num = document.querySelectorAll("#bodyPost > tr"); // элементы таблицы
	var pagi_num = document.querySelectorAll(".paginator > span.numPagi"); // номера страниц
  var leftTwo = document.getElementById('leftTwo'); // arrow
  var leftOne = document.getElementById('leftOne'); // arrow
  var rightOne = document.getElementById('rightOne'); // arrow
  var rightTwo = document.getElementById('rightTwo'); // arrow

  var num_ = id.substr(4); // id substr num - вырезать цифру с айди
  var data_page = +target.dataset.page; // data-page (0-10-20-30)
  var variable, _jquery_data_page;

  var first = +num_ - 3; // цикл - начало итерации
  var last = first + 5; // цикл - конец итерации
  
  if(id == "leftTwo"){ // тык на двойную стрелку влево
    first = 0;
    last = 5;
    data_page = 0; // 0-10
  }else if(id == "rightTwo"){ // тык на двойную стрелку вправо

    first = pagi_num.length - 2;
    last = pagi_num.length;
    data_page = cnt_page * cnt - 10;

  }else if(id == "rightOne"){ // тык на одинарную стрелку вправо

    variable = document.querySelector(".paginator_active").getAttribute("id"); // новый поиск айди страницы (без тыка)
    num_ = +variable.substr(4) + 1; // получение следующего айди (вместо тыка)
    _jquery_data_page = document.querySelector(".paginator_active").getAttribute("data-page"); // attribute (без тыка)
    
    first = +num_ - 3;
    last = first + 5;
    if(num_ <= 3){
      first = 0;
      last = 5;
    }
    data_page = +_jquery_data_page + cnt; // вытащить атрибут data-page + cnt = след 10 записей

  }else if(id == "leftOne"){ // тык на одинарную стрелку влево

    variable = document.querySelector(".paginator_active").getAttribute("id"); // новый поиск айди страницы (без тыка)
    num_ = +variable.substr(4) - 1; // получение следующего айди (вместо тыка)
    _jquery_data_page = document.querySelector(".paginator_active").getAttribute("data-page"); // attribute (без тыка)
    
    if(num_ > cnt_page - 2){ // 13(12,11) > 14 - 2 == 3 element
      first = cnt_page - 3; // 13 = 14 - 1
      last = cnt_page; // 14 = 11 + 5
    }else{
      first = +num_ - 3; // ? = 12 - 2
      last = first + 5;
    }
    /*if(num_ > cnt_page - 3){
      first = 0;
      last = 5;
    }*/
    data_page = +_jquery_data_page - cnt; // вытащить атрибут data-page + cnt = след 10 записей
  }

  main_page = document.getElementById("page" + num_); // ткнули сюда - id page

  if(num_ > 1 || id == "rightTwo") leftOne.style.display = "inline-block";
    else leftOne.style.display = "none";

  if(leftTwo || id == "rightTwo"){
    if(num_ > 2 || id == "rightTwo") leftTwo.style.display = "inline-block";
    else leftTwo.style.display = "none";
  }

  if(pagi_num.length == num_ || id == "rightTwo") rightOne.style.display = "none";
    else rightOne.style.display = "inline-block";

  if(leftTwo || id == "rightTwo"){
    if(num_ > pagi_num.length - 2 || id == "rightTwo") rightTwo.style.display = "none";
      else rightTwo.style.display = "inline-block";
  }

  // страницы
  for (var i = 0; i < pagi_num.length; i++) {
    pagi_num[i].classList.remove("paginator_active"); // удаление всех активных классов
    
    if(i >= first && i < last){
      pagi_num[i].style.display = "inline-block"; // отображение 5-и страниц

      if(main_page == pagi_num[i]){
        pagi_num[i].classList.add("paginator_active"); // добавление активного класса к нажатой кнопке
      }
    }else{
      pagi_num[i].style.display = "none"; // скрытие всех страниц
    }
  }
  if(id == "leftTwo") pagi_num[0].classList.add("paginator_active");
  else if(id == "rightTwo") pagi_num[pagi_num.length-1].classList.add("paginator_active");

	// работа с отображением элементов
  for (var i = 0; i < div_num.length; i++) {
    div_num[i].style.display = "none";
  }

	var j = 0;
	for (var i = data_page; i < div_num.length; i++) {
		if (j >= cnt) break;
		div_num[i].style.display = "table-row";
		j++;
	}

}









// Строка для возвращаемого результата
/*$return_page = "";
// Через GET-параметр page передается номер
// текущей страницы
if(isset($_GET['page'])) $page = $_GET['page'];
if(empty($page)) $page = 1;
// Вычисляем число страниц в системе
$total = getAllPost($link);
$number = (int)($total/get_pnumber());
if((float)($total/get_pnumber()) - $number != 0)
{
  $number++;
}

// Ссылка на первую страницу
$return_page .= "<a href='$_SERVER[PHP_SELF]". "?page=1'>"."&lt;&lt;</a> ... ";

// Выводим ссылку "Назад", если это не первая страница
if($page != 1) $return_page .= " <a href='$_SERVER[PHP_SELF]"."?page=".($page - 1)."'>"."&lt;</a> ... "; 
// Выводим предыдущие элементы
if($page > get_page_link() + 1)
{
  for($i = $page - get_page_link(); $i < $page; $i++)
  {
    $return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
  }
}
else
{
  for($i = 1; $i < $page; $i++)
  {
    $return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
  }
}
// Выводим текущий элемент
$return_page .= "$i ";
// Выводим следующие элементы
if($page + get_page_link() < $number) 
{
  for($i = $page + 1; $i <= $page + get_page_link(); $i++)
  {
    $return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
  }
}
else
{
  for($i = $page + 1; $i <= $number; $i++)
  {
    $return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
  }
}
// Выводим ссылку "вперед", если это не последняя страница
if($page != $number) $return_page .= " ... <a href='"."$_SERVER[PHP_SELF]?page=".($page + 1)."'>"."&gt;</a>"; 
// Ссылка на последнюю страницу
$return_page .= " ... <a href='$_SERVER[PHP_SELF]"."?page=$number'>"."&gt;&gt;</a>"; 
return $return_page;*/






/*var count = $("#bodyPost > tr").length; //всего записей
var cnt = 10; //сколько отображаем сначала
var cnt_page = Math.ceil(count / cnt); //кол-во страниц

//выводим список страниц
var paginator = document.querySelector(".paginator");
var page = "";
for (var i = 0; i < cnt_page; i++) {
  page += "<span data-page=" + i * cnt + " id=\"page" + (i + 1) + "\">" + (i + 1) + "</span>";
}
paginator.innerHTML = page;

//выводим первые записи {cnt}
var div_num = document.querySelectorAll("#bodyPost > tr");
//alert(div_num);
for (var i = 0; i < div_num.length; i++) {
  if (i < cnt) {
    div_num[i].style.display = "table-row";
  }
}

var main_page = document.getElementById("page1");
main_page.classList.add("paginator_active");*/

//листаем
/*function pagination(event) {

  var e = event || window.event;
  var target = e.target;
  var id = target.id;
  
  if (target.tagName.toLowerCase() != "span") return;
  
  var num_ = id.substr(4);
  var data_page = +target.dataset.page;
  main_page.classList.remove("paginator_active");
  main_page = document.getElementById(id);
  main_page.classList.add("paginator_active");

  var j = 0;
  for (var i = 0; i < div_num.length; i++) {
    var data_num = div_num[i].dataset.num;
    if (data_num <= data_page || data_num >= data_page)
      div_num[i].style.display = "none";

  }
  for (var i = data_page; i < div_num.length; i++) {
    if (j >= cnt) break;
    div_num[i].style.display = "block";
    j++;
  }
}*/

