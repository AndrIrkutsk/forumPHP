<?php
	session_start();
	require_once('config.php');
	require_once('dbconnect.php');
	require_once('script.php');

    if (isset($_GET["registration"])){	
    	registration($link);
	}else if(isset($_GET["requestLogin"])){
    	requestLogin($link);
	}else if(isset($_GET["searchpost"])){
    	searchpost($link);
	}else if(isset($_GET["otvetpost"])){
    	otvetpost($link);
	}else if(isset($_GET["otvetpostotvet"])){
    	otvetpostotvet($link);
	}

	function otvetpostotvet($link){
		$param = post();
		$idpost = $param['idpost'];
		$hidpos = $param['hidpos'] + 1;
		$userOtvet = $param['userOtvet'];
		$textOtvet = $param['textOtvet'];
		$iduser = "";
		if(isset($_SESSION["userid"])) $iduser = $_SESSION['userid'];
		$date = date('Y-m-d H:i:s');

		// print($hid_post." || ".$idpost." || ".$userOtvet." || ".$textOtvet);
		$result = [];
		
		if($userOtvet == ""){
			$result['error']['userOtvet'] = "<p class='errorMessage'>Введите Имя!</p>";
		}elseif(strlen($userOtvet) > 0 && strlen($userOtvet) < 2){
			$result['error']['userOtvet'] = "<p class='errorMessage'>Имя должно быть не менее 2-х символов!</p>";
		}

		if(strlen($textOtvet) < 1){
			$result['error']['textOtvet'] = "<p class='errorMessage'>Введите Описание не менее 2-х символов</p>";
		}

		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $userOtvet)) $flag = true;
		if(preg_match_all($pattern, $textOtvet)) $flag = true;

		if (!$flag){ // проверка спец.символов
			if(empty($result['error'])){

				$query = "SELECT * FROM `otvet` WHERE id='$idpost' AND `del`=0";
				if ($res = mysqli_query($link, $query)) {
				    if ($row = mysqli_fetch_assoc($res)) {
				        
						$res = mysqli_query($link, "INSERT INTO `kommotvet` SET `idotvet` = '" . $idpost. "', `iduser` = '" . $iduser. "', `name` = '" . $userOtvet. "', `opis` = '" . $textOtvet. "', `posit` = '" . $hidpos. "', `dates` = '" . $date. "'");
						if($res){
							$result['succ']['luck'] = "<p class='success'>Ответ получен.</p>";
						}

				    }
				}
			}
		}
		echo create_json($result);
	}

	function otvetpost($link){
		$param = post();
		$idpost = $param['idpost'];
		$userOtvet = $param['userOtvet'];
		$textOtvet = $param['textOtvet'];
		$iduser = "";
		if(isset($_SESSION["userid"])) $iduser = $_SESSION['userid'];
		$date = date('Y-m-d H:i:s');

		// print($hid_post." || ".$idpost." || ".$userOtvet." || ".$textOtvet);
		$result = [];
		
		if($userOtvet == ""){
			$result['error']['userOtvet'] = "<p class='errorMessage'>Введите Имя!</p>";
		}elseif(strlen($userOtvet) > 0 && strlen($userOtvet) < 2){
			$result['error']['userOtvet'] = "<p class='errorMessage'>Имя должно быть не менее 2-х символов!</p>";
		}

		if(strlen($textOtvet) < 1){
			$result['error']['textOtvet'] = "<p class='errorMessage'>Введите Описание не менее 2-х символов</p>";
		}

		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $userOtvet)) $flag = true;
		if(preg_match_all($pattern, $textOtvet)) $flag = true;

		if (!$flag){ // проверка спец.символов
			if(empty($result['error'])){

				$query = "SELECT * FROM `otvet` WHERE id='$idpost' AND `del`=0";
				if ($res = mysqli_query($link, $query)) {
				    if ($row = mysqli_fetch_assoc($res)) {
				        
				        $vloshen=+$row["vloshen"] + 1;

						$res = mysqli_query($link, "INSERT INTO `kommotvet` SET `idotvet` = '" . $idpost. "', `iduser` = '" . $iduser. "', `name` = '" . $userOtvet. "', `opis` = '" . $textOtvet. "', `posit` = '" . $vloshen. "', `dates` = '" . $date. "'");
						if($res){
							$result['succ']['luck'] = "<p class='success'>Ответ получен.</p>";
						}

				    }
				}
			}
		}
		echo create_json($result);
	}

	function searchpost($link){
		$param = post();
		$searchitem = $param['searchitem'];

		$result = [];

		if($searchitem == ""){
			$result['error']['noitem'] = "<p class='errorMessage'>Поле поиска пусто!</p>";
		} 

		// js - [!,#,$,%,^,&,*,(,),[,\],{,},?,>,<,",',№,;,:,=,`,~,|,+,\,]
		if( !(preg_match("/[!#$%^&*?><\"\'№;:=+`~|\[\]\(\)\{\}\\\]/i", $searchitem)) ){ // проверка спец.символов
			if(empty($result['error']) && strlen($searchitem) > 1){
								
				$data = "";
				
				$tbl = mysqli_query($link, "SELECT * FROM `nametheme` WHERE name LIKE '%$searchitem%'");
				if(!$tbl){
					$result['error']['error_table'] = "<p class='errorMessage'>Ошибка обращения к таблице позиций<br>{mysql_error()}<br>$query</p>";
				}
				while($row = mysqli_fetch_assoc($tbl))
				{	
					$data.="<tr class=\"num\">
							   <td>$row[id]</td>
							   <td>$row[nameuser]</td>
							   <td><a href=\"http://forum/script/posts.php?postid=$row[id]\">".splitTextName($row["name"])."</a></td>
							   <td>".splitTextOpis($row["opis"])."</td>
							   <td class=dateRow>".transformDate($row["date"])."</td>
						    </tr>";
				}


				if(empty($data)){
					$data = '<tr>
								<td colspan="5" class="result-not-found">Постов по данному запросу не найдено 
								  <i class="fa fa-frown-o" aria-hidden="true"></i>
								</td>
							</tr>
							';
				}
				echo($data);

			}
		}else{ // ошибка
			echo create_json($result);
		}

	}


	function registration($link){
		$param = post();
		$username = $param['userName'];
		$useremail = $param['useremail'];
		$login = $param['login'];
		$password = $param['password'];
		$password_conf = $param['password_conf'];
		$img_id = $param['img'];
		if(!$img_id) $img_id = 5;

		$result = [];

		if(strlen($username) < 2){
			$result['error']['username'] = "<p class='errorMessage'>Введите Никнейм! (Не менее 2-х символов)</p>";
		}

		$pattern="/[\w\.-]+@[\w\.-]+.[\w]+/i";
		if (!preg_match($pattern, $useremail)) {
		    $result['error']['email'] = "<p class='errorMessage'>Email некорректен!</p>";
		}

		if(strlen($login) < 5){
			$result['error']['login'] = "<p class='errorMessage'>Введите логин! (Не менее 5-и символов)</p>";
		}
		if(strlen($password) < 5){
			$result['error']['password'] = "<p class='errorMessage'>Введите пароль! (Не менее 5-и символов)</p>";
		}
		if($password !== $password_conf){
			$result['error']['password_conf'] = "<p class='errorMessage'>Пароли не совпадают</p>";
		}

		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $username)) $flag = true;
		if(preg_match_all($pattern, $useremail)) $flag = true;
		if(preg_match_all($pattern, $login)) $flag = true;
		if(preg_match_all($pattern, $password)) $flag = true;
		if(preg_match_all($pattern, $password_conf)) $flag = true;


		if (!$flag){ // проверка спец.символов
			if(empty($result['error'])){
				// registration

				$tbl = mysqli_query($link, "SELECT * FROM users WHERE username='$username'");
				if(!$tbl){
					$result['error']['error_table'] = "<p class='errorMessage'>Ошибка обращения к таблице позиций<br>{mysql_error()}<br>$query</p>";
				} 
				// Если имеется хотя бы один элемент, регистрация не проходит
				if($tbl->num_rows)
				{	
					$result['error']['username'] = "<p class='errorMessage error_user'>Такой Никнейм уже используется!</p>";
				}

				$tbl = mysqli_query($link, "SELECT * FROM users WHERE email='$useremail'");
				if($tbl->num_rows)
				{	
					$result['error']['email'] = "<p class='errorMessage error_email'>Такой Email уже используется!</p>";
				}

				if(isset($result['error'])){
					echo create_json($result);
				}else{
					$respass = password_hash($password, PASSWORD_DEFAULT);
					$confcod=md5(date("U")."w/*/*a".$login."-=-".$username);
					$date=date('Y-m-d H:i:s');

					$result['succ']['forum_hash'] = $confcod;
					$result['succ']['luck'] = "<p class='success'>Вы прошли регистрацию</p>";

					// Установка данных в таблицу
					$tbl = mysqli_query($link, "INSERT INTO users (username, avatar, login, pass, email, dateadd, confcod) VALUES ('$username', '$img_id', '$login', '$respass', '$useremail', '$date', '$confcod')");

					// $sql = "INSERT INTO users (username, login, pass, email, dateadd, confcod) 
					// VALUES ('$username', '$login', '$respass', '$useremail', '$date', '$confcod')";

					if ($tbl) {
						echo create_json($result);
					} else {
						$result['error']['other'] = "<p class='success'>Произошла ошибка</p>";
					   	echo create_json($result);
					}
				}
			}else{
				echo create_json($result);
			}
		}
	}

	function requestLogin($link){
		$param = post();
		$login = $param['login'];
		$password = $param['password'];

		$result = [];
		
		if($login == ""){
			$result['error']['login'] = "<p class='errorMessage'>Введите логин!</p>";
		}

		if(strlen($login) > 0 && strlen($login) < 2){
			$result['error']['login'] = "<p class='errorMessage'>Введите логин не менее 2-х символов!</p>";
		}

		if(strlen($password) < 1){
			$result['error']['password'] = "<p class='errorMessage'>Введите пароль!</p>";
		}

		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $login)) $flag = true;
		if(preg_match_all($pattern, $password)) $flag = true;


		if (!$flag){ // проверка спец.символов
			if(empty($result['error'])){
				// Получаем пользователя по логину
				$tbl = mysqli_query($link, "SELECT * FROM users WHERE login='$login'");
				if(!$tbl){
					$result['error']['error_table'] = "<p class='errorMessage'>Ошибка обращения к таблице позиций<br>{mysql_error()}<br>$query</p>";
				}
				if($row = mysqli_fetch_assoc($tbl))
				{	
					if (password_verify($password, $row['pass'])){
						$_SESSION["userid"]=$row["id"];
						$_SESSION["username"]=$row["username"];

						$result['succ']['luck'] = "<p class='success'>Вы успешно авторизовались.</p>";
					}else{
						$result['error']['data'] = "<p class='errorMessage'>Данные для входа не верны!</p>";
					}
					echo create_json($result);
				}
			}else{
			 	echo create_json($result);
			}
		}
	}

	// Функция конвертации массивов для javascript
	function create_json($array){

		header('Content-Type: application/json');
		return json_encode($array);
	}

	function post(){
		return cleanData($_POST);
	}

	function cleanData($data){
		if(is_array($data)){
			foreach($data as $key => $value){
				unset($data[$key]);
				
				$data[cleanData($key)] = cleanData($value);
			}
			return $data;
		}
		return htmlspecialchars($data, ENT_COMPAT, 'UTF-8');
	}

	function query($query){
		return mysqli_query($link, $query);
	}

	function get_result($result){
		$data = [];
		
		while($row = mysqli_fetch_assoc($result)){
			$data[] = $row;
		}

		return $data;
	}

?>