<?php
	ini_set('error_reporting', E_ALL);
	
	define("HOST", "localhost");
	define("USER", "root");
	define("PASSWORD", "");
	define("DBNAME", "forum");

	define('SYS_ENCODING', 'UTF-8');

	$link = mysqli_connect(HOST, USER, PASSWORD, DBNAME);
	if (!$link) {
	    echo "Ошибка: Невозможно установить соединение с MySQL." . PHP_EOL;
	    echo "Код ошибки errno: " . mysqli_connect_errno() . PHP_EOL;
	    echo "Текст ошибки error: " . mysqli_connect_error() . PHP_EOL;
	    exit;
	}
	$date = date("Y-m-d H:i:s");


	/*for ($i=0; $i < 100; $i++) { 

		$res = mysqli_query($link, "INSERT INTO `nametheme` SET `name` = 'rtrtrtrtrtrt', `opis` = 'rtrtrtrtrtrt', `date` = '" . $date. "'");
	}*/


?>