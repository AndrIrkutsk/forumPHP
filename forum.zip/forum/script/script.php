<?php
	// построение шаблона 
	// шапка
	function headers($title){
		$css = asset(
			[
				['name' => 'main'],
				['name' => 'style'],
				['name' => 'icomoon/style'],
				['name' => 'fullcalendar'],
				['name' => 'form']
			],
			'css'
		);
		$pathTemplate = '../templ/header.php';		
		if(is_file($pathTemplate)){
			include_once $pathTemplate;
		}
	}

	// подвал
	function footer(){
		$js = asset(
			[
				['name' => 'basari/jquery.min'],
				['name' => 'basari/bootstrap'],
				['name' => 'basari/jquery-ui-1.8.23.custom.min'],
				['name' => 'basari/morris/morris'],
				['name' => 'basari/morris/raphael-min'],
				['name' => 'basari/flot/jquery.flot'],
				['name' => 'basari/flot/jquery.flot.resize.min'],
				['name' => 'basari/fullcalendar'],
				['name' => 'basari/tiny-scrollbar'],
				['name' => 'basari/custom-index'],
				['name' => 'basari/custom'],
				['name' => 'page']
			],
			'js'
		);
		$pathTemplate = '../templ/footer.php';
		if(is_file($pathTemplate)){
			include_once $pathTemplate;
		}
	}

	// подключение стилей и js-файла
	function asset($param = [], $type = 'css'){
		$pathCSS = '../css/';
		$pathJS = '../js/';
		$listFiles = [];
		$pathFileByName="";

		if($type=='js'){	
			foreach ($param as $item) {
				$pathFileByName = $pathJS . $item['name'] . ".js";
				if(is_file($pathFileByName)){
					$listFiles[] = $pathFileByName;
				}
			}
		}else{
			foreach ($param as $item) {
				$pathFileByName = $pathCSS . $item['name'] . ".css";
				if(is_file($pathFileByName)){
					$listFiles[] = $pathFileByName;
				}
			}
		}
		return $listFiles;
	}


	// преобразование даты
	function transformDate($date){
		// объекты времени отправки и сейчас
		$timeSend = new DateTime($date);
		$timeNow = new DateTime();
		// время отправки и сейчас в формате
		$timeNows = $timeNow->format("Y-m-d H:i:s");
		$timeSendForm = $timeSend->format("Y-m-d H:i:s");
		$lastTime = $timeSend->format("H:i");
		// время сегодня в 00:00
		$todayBegday = date("Y-m-d H:i:s", mktime(0, 0, 0)); // сегодня в 00
		// вчера в 00:00
		$dayYester = date('Y-m-d H:i:s', strtotime('yesterday')); // вчера в 00:00
		
		$lastOneDay="";			
		$datevis = $timeNow->format("U");
		$dateminus = date("U") - 300; // менее 5-ти минут назад
		// паттерны замены
		$patterns_dayWeek = array('/Monday/', '/Tuesday/', '/Wednesday/', '/Thursday/', '/Friday/', '/Saturday/', '/Sunday/');
		$replace_dayWeek = array('Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс', 'Марта');
		$patterns_month = array('/Jan/', '/Feb/', '/Mar/', '/Apr/', '/May/', '/Jun/', '/Jul/', '/Aug/', '/Sep/', '/Oct/', '/Nov/', '/Dec/');
		$replace_month = array('Янв.', 'Фев.', 'Марта', 'Апр.', 'Мая', 'Июня', 'Июля', 'Авг.', 'Сен.', 'Окт.', 'Ноя.', 'Дек.');

		if($timeSendForm > $dateminus){
			$lastOneDay="Менее 5-ти минут назад";
		}elseif($timeSendForm >= $todayBegday && $datevis < $dateminus){
			$lastOneDay = "Сегодня в ".$lastTime;
		}elseif($timeSendForm >= $dayYester && $timeSendForm < $todayBegday){ // если дата последнего визита больше вчерашней даты с 00:00 до сегодня 00:00 - то это вчера
			$lastOneDay = "Вчера в ".$lastTime;
		}else{
			$lastOneDay = $timeSend->format("l, d M Y г. в H:i"); // Вторник, 2019 г. в 22:10
			$lastOneDay = preg_replace($patterns_dayWeek, $replace_dayWeek, $lastOneDay); 
			$lastOneDay = preg_replace($patterns_month, $replace_month, $lastOneDay); 
		}
		return $lastOneDay;
	}

	// функция разрезания строки до нужного кол-ва символов в имени
	function splitTextName($text){
		$size = mb_strlen($text, 'utf-8');
		if($size > 25){
			return mb_substr($text, 0, 25, 'utf-8')."...";
		}
		return $text;	
	}
	// функция разрезания строки до нужного кол-ва символов в описании
	function splitTextOpis($text){
		$size = mb_strlen($text, 'utf-8');
		if($size > 30){
			return mb_substr($text, 0, 30, 'utf-8')."...";
		}
		return $text;	
	}

	///////////////////////////////////////
	////////////    pagination    /////////
	///////////////////////////////////////
	function getAllPost($link){
		$query = "SELECT COUNT(*) AS total FROM nametheme WHERE `del`=0";
		$allData = $link->query($query);
		if(!$allData) exit("Ошибка обращения к каталогу");
		$result = $allData->fetch_object();
		return $result->total; 
	}

	// количество записей на странице
	function get_pnumber()
	{
		return 10;
	}

	// количество страниц посередине
	function get_page_link()
	{
		return 2;
	}

	// получение элементов из базы для вывода
	function get_page($link)
	{	
		// Текущая страница
		if(isset($_GET['page'])) $page = $_GET['page'];
		if(empty($page)) $page = 1;
		// Количество записей в файле
		$total = getAllPost($link);
		// Вычисляем количество страниц в системе
		$number = (int)($total/get_pnumber());
		if((float)($total/get_pnumber()) - $number != 0) $number++;
		// Проверяем, попадает ли запрашиваемый номер
		// страницы в интервал от 1 до total
		if($page <= 0 || $page > $number) return 0;
		// Извлекаем позиции текущей страницы
		$arr = array();
		// Номер, начиная с которого следует
		// выбирать строки файла
		$first = ($page - 1)*get_pnumber();
		// Извлекаем позиции для текущей страницы
		$query = "SELECT * FROM `nametheme` WHERE `del`=0 ORDER BY id DESC LIMIT $first, ".get_pnumber()."";
		$tbl = $link->query($query);
		if(!$tbl) exit("Ошибка обращения к таблице позиций<br>{mysql_error()}<br>$query");
		// Если имеется хотя бы один элемент,
		// заполняем массив $arr
		if($tbl->num_rows)
		{
			while($catalogs = $tbl->fetch_array())
			{
				$arr[] = $catalogs;
			}
		}
		// Удаляем последний нулевой элемент
		// массива $arr
		//unset($arr[count($arr) - 1]);
		return $arr;
	}

	// вывод ссылок на пагинацию
	function print_page($link)
	{
	    // Строка для возвращаемого результата
	    $return_page = "";
	    // Через GET-параметр page передается номер
	    // текущей страницы
	    if(isset($_GET['page'])) $page = $_GET['page'];
	    if(empty($page)) $page = 1;
	    // Вычисляем число страниц в системе
	    $total = getAllPost($link);
	    $number = (int)($total/get_pnumber());
	    if((float)($total/get_pnumber()) - $number != 0)
	    {
	      $number++;
	    }

	    $return_page .= "<ul class=\"pagination\">";
	    $return_page .= "<li><a class=\"first_last\" href='$_SERVER[PHP_SELF]". "?page=1'>&laquo;&laquo;</a></li>";
	    
	    // Ссылка на первую страницу
	    //$return_page .= "<a href='$_SERVER[PHP_SELF]". "?page=1'>"."&lt;&lt;</a> ... ";

	    // Выводим ссылку "Назад", если это не первая страница
	    //if($page != 1) $return_page .= " <a href='$_SERVER[PHP_SELF]"."?page=".($page - 1)."'>"."&lt;</a> ... "; 
	    if($page != 1) $return_page .= "<li><a href='$_SERVER[PHP_SELF]"."?page=".($page - 1)."'>&laquo;</a></li>"; 
	    // Выводим предыдущие элементы
	    if($page > get_page_link() + 1)
	    {
	      for($i = $page - get_page_link(); $i < $page; $i++)
	      {
	        //$return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
	        $return_page .= "<li><a href='$_SERVER[PHP_SELF]?page=$i'>$i</a></li>";
	      }
	    }
	    else
	    {
	      for($i = 1; $i < $page; $i++)
	      {
	        //$return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
	        $return_page .= "<li><a href='$_SERVER[PHP_SELF]?page=$i'>$i</a></li>";
	      }
	    }
	    // Выводим текущий элемент
	    //$return_page .= "$i ";
	    $return_page .= "<li class=\"active\"><a href='$_SERVER[PHP_SELF]?page=$i'>$i</a></li>";
	    // Выводим следующие элементы
	    if($page + get_page_link() < $number) 
	    {
	      for($i = $page + 1; $i <= $page + get_page_link(); $i++)
	      {
	        //$return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
	        $return_page .= "<li><a href='$_SERVER[PHP_SELF]?page=$i'>$i</a></li>";
	      }
	    }
	    else
	    {
	      for($i = $page + 1; $i <= $number; $i++)
	      {
	        //$return_page .= "<a href='$_SERVER[PHP_SELF]?page=$i'>$i</a> ";
	        $return_page .= "<li><a href='$_SERVER[PHP_SELF]?page=$i'>$i</a></li>";
	      }
	    }
	    // Выводим ссылку "вперед", если это не последняя страница
	    //if($page != $number) $return_page .= " ... <a href='"."$_SERVER[PHP_SELF]?page=".($page + 1)."'>"."&gt;</a>"; 
	    if($page != $number) $return_page .= "<li><a href='$_SERVER[PHP_SELF]?page=".($page + 1)."'>&raquo;</a></li>"; 
	    // Ссылка на последнюю страницу
	    //$return_page .= " ... <a href='$_SERVER[PHP_SELF]"."?page=$number'>"."&gt;&gt;</a>"; 
	    $return_page .= "<li><a class=\"first_last\" href='$_SERVER[PHP_SELF]"."?page=$number'>&raquo;&raquo;</a></li>"; 
	    $return_page .= "</ul>"; 
	    return $return_page;
	}

?>