<?php 

define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DBNAME", "forum");

define('SYS_ENCODING', 'UTF-8');

?>