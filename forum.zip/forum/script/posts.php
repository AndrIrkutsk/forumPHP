<?php
	session_start();
	ini_set('error_reporting', E_ALL);
	
	require_once('config.php');
	require_once('dbconnect.php');
	require_once('script.php');

	$postid="";
	if(isset($_GET["postid"])) $postid = stripcslashes(strip_tags($_GET["postid"]));

	if(isset($_SESSION["username"])) $otvetName=$_SESSION["username"]; // инициализация если пользователь авторизован
		else $otvetName="Anonymous"; // инициализация если пользователь не авторизован
	
	$result = array();
	$result['error'] = '';

	// вставка в бд ответа на пост
	if(isset($_POST["enterOtvet"])){
		$otvetName = stripcslashes(strip_tags($_POST["otvetName"]));
		$otvetPost = stripcslashes(strip_tags($_POST["otvetPost"]));
		$date = date('Y-m-d H:i:s');
		
		if(strlen($otvetName) < 1){
			$result['error'] .= '<p style=color:red;>Введите Своё Имя!</p>';
		}

		if(strlen($otvetPost) < 1){
			$result['error'] .= '<p style=color:red;>Введите описание поста!</p>';
		}
// to do поиск урл адресов

		// $pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/"; - pattern search spec.simbol in message - not !?.,@/
		$pattern = "/[<>\'\`#$%\^&*(){}[\]+=|:;~№\"\\\]/";
		$flag = false;
		if(preg_match_all($pattern, $otvetName)) $flag = true;
		if(preg_match_all($pattern, $otvetPost)) $flag = true;


		if (!$flag){ // проверка спец.символов
			if(empty($result['error'])){ // добавление поста
				if(isset($_SESSION["userid"])){
					$res = mysqli_query($link, "INSERT INTO `otvet` SET `iduser` = '" .$_SESSION["userid"]. "', `idpost` = '" . $postid. "', `nameuser` = '" . $otvetName. "', `opis` = '" . $otvetPost. "', `vloshen` = '1', `dates` = '" . $date. "'");
				}else{
					$res = mysqli_query($link, "INSERT INTO `otvet` SET `idpost` = '" . $postid. "', `nameuser` = '" . $otvetName. "', `opis` = '" . $otvetPost. "', `vloshen` = '1', `dates` = '" . $date. "'");
				}
				if($res){
					header("Location: http://forum/script/posts.php?postid=" . $postid . "&succ");
					exit;
				}
			}
		}else{
			$result['error'] .= '<p style=color:red;>Спец.символы запрещены!</p>';
		}
	}
	
	// шаблон показа поста и комментариев
	$tmp = file_get_contents("../templ/rules.tmpl");

	$nameuser_p=$name_p="";
	// запрос на извлечение главного поста
	$query = "SELECT * FROM `nametheme` WHERE id='$postid' AND `del`=0";
	$tbl = $link->query($query);
	if(!$tbl) exit("Ошибка обращения к таблице позиций<br>{mysql_error()}<br>$query");
	if($tbl->num_rows)
	{
		if($catalogs = $tbl->fetch_array())
		{
			$id_p = $catalogs["id"];
			$nameuser_p = $catalogs["nameuser"];
			$name_p = $catalogs["name"];
			$opis_p = $catalogs["opis"];
			$dateadd_p = transformDate($catalogs["date"]);
		}
	}
			
$iduser=$chat=$class_color="";
$nameuser=$opis=$res_us="";
$mon=$dayTime=$mtime=$date="";

	
	$query = "SELECT * FROM `otvet` WHERE idpost='$postid' AND `del`=0";
	if ($res = mysqli_query($link, $query)) {
	    /* извлечение ассоциативного массива */
	    while ($row = mysqli_fetch_assoc($res)) {
	        
	        $id=$row["id"];
	        $nameuser=$row["nameuser"];
	        $opis=$row["opis"];

	        $date = new DateTime($row["dates"]);	
			$mtime=$date->format('H:i');
			$dayTime=$date->format('j');
			$mon=$date->format('F');

			$chat_otv=$class=$style=$otv_avatar="";
			$date_ot=$mtime_ot=$dayTime_ot=$mon_ot=$posit_otv=$resposit="";

	    	$queryOtv = "SELECT * FROM `kommotvet` WHERE idotvet='$id' AND `del`=0 ORDER BY posit";
	        if ($res_ot = mysqli_query($link, $queryOtv)) {
			    while ($row_ot = mysqli_fetch_assoc($res_ot)) {
			    	$id_otv=$row_ot["id"];
			    	$idus_otv=$row_ot["iduser"];
			    	$name_otv=$row_ot["name"];
			    	$opis_otv=$row_ot["opis"];
			    	$posit_otv=$row_ot["posit"];
			    	$dates_otv=$row_ot["dates"];

			    	if($idus_otv != 0){   		
				    	$queryUs_ot = "SELECT * FROM `users` WHERE id='$idus_otv' AND `del`=0 AND `conf`=1";
				        if ($res_us_ot = mysqli_query($link, $queryUs_ot)) {
						    if ($row_us_ot = mysqli_fetch_assoc($res_us_ot)) {
						        
						        $queryAv_ot = "SELECT * FROM `avatar` WHERE id='$row_us_ot[avatar]' AND `del`=0";
						        if ($res_av_ot = mysqli_query($link, $queryAv_ot)) {
								    if ($row_av_ot = mysqli_fetch_assoc($res_av_ot)) {
								       $otv_avatar = $row_av_ot["name"];
								    }
								}

						    }
						}
			    	}else{
			    		$queryAv_ot = "SELECT * FROM `avatar` WHERE id=9 AND `del`=0";
				        if ($res_av_ot = mysqli_query($link, $queryAv_ot)) {
						    if ($row_av_ot = mysqli_fetch_assoc($res_av_ot)) {
						       $otv_avatar = $row_av_ot["name"];
						    }
						}
			    	}

			    	$resposit = ($posit_otv - 1) * 30 ."px";
			    	$style="style='margin-left: $resposit'";
			    	
			    	if($posit_otv >= 2) $class="post_".$posit_otv;
			    	
			    	switch ($posit_otv) {
			    		case 1: $class_color = "info"; break;
			    		case 2: $class_color = "warning"; break;
			    		case 3: $class_color = "success"; break;
			    		case 4: $class_color = "error"; break;
			    		case 5: $class_color = "info"; break;
			    		case 6: $class_color = "warning"; break;
			    		case 7: $class_color = "success"; break;
			    		case 8: $class_color = "error"; break;
			    	}
			    	$date_ot = new DateTime($row_ot["dates"]);	
					$mtime_ot=$date_ot->format('H:i');
					$dayTime_ot=$date_ot->format('j');
					$mon_ot=$date_ot->format('F');

			    	$chat_otv .= "<li class=\"".$class." topm\" $style data-id=\"".$id."\" data-pos=\"".$posit_otv."\">
						                  <img src=\"../img/".$otv_avatar."\" class=\"avatar\" alt=\"Avatar\"/>
						                  <div class=\"message-date\">
						                    <h3 class=\"date text-".$class_color."\">".$dayTime_ot."</h3>
						                    <p class=\"month\">".$mon_ot."</p>
						                    <span>".$mtime_ot."</span>
						                  </div>
						                  <div class=\"message-wrapper\">
						                    <h4 class=\"message-heading\">".$name_otv."</h4>
						                    <p class=\"message\">
						                     ".$opis_otv." <a href=\"#createOtv\" class=\"linOtv\" data-toggle=\"modal\" onclick=\"showvloshenotv(this);\">+ Ответить</a>
						                    </p>
						                  </div>
						              </li>";
			    }
			}

			$queryUs = "SELECT * FROM `users` WHERE id='$row[iduser]' AND `del`=0 AND `conf`=1";
	        if ($res_us = mysqli_query($link, $queryUs)) {
			    while ($row_us = mysqli_fetch_assoc($res_us)) {
			        
			        //$iduser .= $row_us["avatar"]." ";
			        $queryAv = "SELECT * FROM `avatar` WHERE id='$row_us[avatar]' AND `del`=0";
			        if ($res_av = mysqli_query($link, $queryAv)) {
					    while ($row_av = mysqli_fetch_assoc($res_av)) {
					        
					        $iduser .= $row_av["name"]." ";

					        $chat .= "<li class=\"post_ topm\" data-id=\"".$row["id"]."\">
						                  <img src=\"../img/".$row_av["name"]."\" class=\"avatar\" alt=\"Avatar\"/>
						                  <div class=\"message-date\">
						                    <h3 class=\"date text-".$class_color."\">".$dayTime."</h3>
						                    <p class=\"month\">".$mon."</p>
						                    <span>".$mtime."</span>
						                  </div>
						                  <div class=\"message-wrapper\">
						                    <h4 class=\"message-heading\">".$nameuser."</h4>
						                    <p class=\"message\">
						                     ".$opis." <a href=\"#createFilter\" class=\"linOtv\" data-toggle=\"modal\" onclick=\"showvloshen(this);\">+ Ответить</a>
						                    </p>
						                  </div>
						              </li>".$chat_otv;

					    }
					}

			    }
			}

	    }
	    /* удаление выборки */
	    mysqli_free_result($res);
	    //mysqli_free_result($res_us);
	    //mysqli_free_result($res_av);
	}

	/* закрытие соединения */
	mysqli_close($link);


	$tmp= str_replace("{[idpost]}", $id_p, $tmp);
	$tmp= str_replace("{[nameuser]}", $nameuser_p, $tmp);
	$tmp= str_replace("{[namepost]}", $name_p, $tmp);
	$tmp= str_replace("{[opis]}", $opis_p, $tmp);
	$tmp= str_replace("{[dateadd]}", $dateadd_p, $tmp);

	$tmp= str_replace("{[nameusr]}", $otvetName, $tmp);
	$tmp= str_replace("{[error]}", $result['error'], $tmp);

	$tmp= str_replace("{[chat]}", $chat, $tmp);
	
	headers("пост");
	print($tmp);
	footer();
?>