       <?php  foreach ($js as $jscript) { ?>
            <script src="<?= $jscript ?>"></script>
        <?php } ?>
	</body>
</html>
