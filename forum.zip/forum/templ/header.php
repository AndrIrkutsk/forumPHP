<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title; ?></title>

    <?php  foreach ($css as $style) { ?>
        <link href="<?= $style ?>" rel="stylesheet" />
    <?php } ?>
</head>
<body>
