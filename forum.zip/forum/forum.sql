-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 20 2019 г., 13:21
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `forum`
--

-- --------------------------------------------------------

--
-- Структура таблицы `avatar`
--

CREATE TABLE `avatar` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `avatar`
--

INSERT INTO `avatar` (`id`, `name`, `del`) VALUES
(1, 'avatar-1.png', 0),
(2, 'avatar-2.png', 0),
(3, 'avatar-3.png', 0),
(4, 'avatar-4.png', 0),
(5, 'avatar-5.png', 0),
(6, 'avatar-6.png', 0),
(7, 'avatar-7.png', 0),
(8, 'avatar-8.png', 0),
(9, 'nofoto.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `kommotvet`
--

CREATE TABLE `kommotvet` (
  `id` int(11) NOT NULL,
  `idotvet` int(11) NOT NULL DEFAULT '0',
  `iduser` int(11) NOT NULL DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `opis` text,
  `posit` smallint(6) NOT NULL DEFAULT '0',
  `dates` datetime DEFAULT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kommotvet`
--

INSERT INTO `kommotvet` (`id`, `idotvet`, `iduser`, `name`, `opis`, `posit`, `dates`, `del`) VALUES
(1, 9, 0, 'artem', 'rerererre gdfg3234234 errr', 2, '2019-08-19 08:27:31', 0),
(2, 15, 0, 'artem', 'yrtyryryt', 2, '2019-08-19 08:30:11', 0),
(3, 16, 0, 'artem', 'gggrgrertertert', 2, '2019-08-19 08:31:57', 0),
(4, 14, 0, 'artem', 'helo worlsd', 2, '2019-08-19 08:39:57', 0),
(5, 16, 0, 'artem', 'rewrerwerwr', 2, '2019-08-19 08:47:37', 0),
(6, 10, 0, 'artem', 'rere', 2, '2019-08-19 08:48:30', 0),
(7, 15, 2, 'artem', 'eerwerwrwer', 2, '2019-08-19 08:49:51', 0),
(8, 10, 2, 'artem', 'rwrwerwre', 2, '2019-08-19 08:52:48', 0),
(9, 9, 2, 'artem', 'sdfsdfsdfsdf', 2, '2019-08-19 08:53:36', 0),
(10, 10, 2, 'artem', 'retetete', 2, '2019-08-19 08:55:26', 0),
(11, 10, 2, 'artem', 'ku ku ku ku', 2, '2019-08-19 08:58:36', 0),
(12, 10, 2, 'archi', 'my text', 2, '2019-08-19 09:00:24', 0),
(13, 14, 2, 'artem', 'thirth vloshennostb', 3, '2019-08-20 08:35:12', 0),
(14, 14, 2, 'artem', 'firth post otvet', 4, '2019-08-20 09:06:31', 0),
(15, 14, 2, 'artem', 'rwerwerwerwer', 4, '2019-08-20 09:19:15', 0),
(16, 14, 2, 'artem', 'ты дурак?', 4, '2019-08-20 09:20:14', 0),
(17, 14, 2, 'artem', 'ответ на htllo world', 3, '2019-08-20 09:20:38', 0),
(18, 17, 2, 'artem', 'us us us', 2, '2019-08-20 09:43:07', 0),
(19, 17, 2, 'artem', 'ну ка помт', 3, '2019-08-20 09:43:47', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `nametheme`
--

CREATE TABLE `nametheme` (
  `id` int(11) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `nameuser` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `opis` text,
  `date` datetime DEFAULT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `nametheme`
--

INSERT INTO `nametheme` (`id`, `iduser`, `nameuser`, `name`, `opis`, `date`, `del`) VALUES
(1, NULL, NULL, 'erwr', 'werwr', NULL, 0),
(2, NULL, NULL, 'hello', 'help me', NULL, 0),
(3, NULL, NULL, 'hello world', 'my name is Peter', NULL, 0),
(4, NULL, NULL, 'hello world', 'my name is Peter', NULL, 0),
(5, NULL, NULL, 'hello world', 'my name is Peter', NULL, 0),
(6, NULL, NULL, 'rtertert', 'ertete', NULL, 0),
(7, NULL, NULL, 'rteterte', 'ertetetet', NULL, 0),
(8, NULL, NULL, 'ertetet', 'rtertet', NULL, 0),
(9, NULL, NULL, 'ertetet', 'rtertet', NULL, 0),
(10, NULL, NULL, 'hi bro', 'iam Andrey', NULL, 0),
(11, NULL, NULL, 'hi bro', 'iam Andrey', NULL, 0),
(12, NULL, NULL, 'kills', 'kill this script', NULL, 0),
(13, NULL, NULL, 'kills', 'kill this script', NULL, 0),
(14, NULL, NULL, 'kills', 'kill this script', NULL, 0),
(16, NULL, NULL, 'hello world', 'mfdsdfsdfzsfsfzsfzs', NULL, 0),
(17, NULL, NULL, 'hoppp', 'hoppe', NULL, 0),
(18, NULL, NULL, 'hoppe hoppe', 'hope your friend', NULL, 0),
(19, NULL, NULL, 'fewefsfs', 'dfsdfdsf', NULL, 0),
(20, NULL, NULL, 'fewefsfs', 'dfsdfdsf', NULL, 0),
(21, NULL, NULL, 'fewefsfs', 'dfsdfdsf', NULL, 0),
(22, NULL, NULL, 'кеукеукеуке', 'кеукеуке', NULL, 0),
(23, NULL, NULL, 'кеукеукеуке', 'кеукеуке', NULL, 0),
(24, NULL, NULL, 'укцукцукцу', 'цукцукцукц', NULL, 0),
(25, NULL, NULL, 'ауыкыукцук', 'цукцукцук', NULL, 0),
(26, NULL, NULL, 'ауыкыукцук', 'цукцукцук', NULL, 0),
(27, NULL, NULL, 'енкенкен', 'кнкен', NULL, 0),
(28, NULL, NULL, 'кеукеукеуке', 'укеукеу', NULL, 0),
(29, NULL, NULL, 'кеукеукеуке', 'укеукеу', NULL, 0),
(30, NULL, NULL, 'хай', 'моя тема', NULL, 0),
(31, NULL, NULL, 'ну ка', 'укцукцукцук', NULL, 0),
(32, NULL, NULL, 'хай бро', 'тут описание поста', NULL, 0),
(33, NULL, NULL, 'кеукеуке', 'кеукеукеукеукеукеуеуе', NULL, 0),
(34, NULL, NULL, 'кеукеуке', 'кеукеукеукеукеукеуеуе', NULL, 0),
(35, NULL, NULL, 'еещ тема', 'эта тема бро', NULL, 0),
(36, NULL, NULL, 'еещ тема', 'эта тема бро', NULL, 0),
(37, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:23:21', 0),
(38, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:26:32', 0),
(39, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:28:47', 0),
(40, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:30:10', 0),
(41, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:33:51', 0),
(42, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:34:42', 0),
(43, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 05:56:44', 0),
(44, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:01:04', 0),
(45, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:02:45', 0),
(46, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:03:11', 0),
(47, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:04:04', 0),
(48, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:04:45', 0),
(49, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:05:26', 0),
(50, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:05:41', 0),
(51, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:05:58', 0),
(52, NULL, NULL, 'кеукеукеrwerewr', 'кеукеукеукеукеукеуеуеwerewrwer', '2019-03-30 06:06:50', 0),
(53, NULL, NULL, 'rtertertert', 'trertertetertertertert', '2019-03-30 06:13:13', 0),
(54, NULL, NULL, 'rtertertert', 'trertertetertertertert', '2019-03-30 06:14:30', 0),
(55, NULL, NULL, 'hello bro', 'my there top', '2019-03-30 06:15:28', 0),
(56, NULL, NULL, 'hello bro', 'my there top', '2019-03-30 06:16:05', 0),
(57, NULL, NULL, 'hello bro', 'my there top', '2019-03-30 06:16:43', 0),
(58, NULL, NULL, 'rterterterterterterterte', 'rtertertertert2323123543453463', '2019-03-30 06:17:05', 0),
(59, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:41:36', 0),
(60, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:49:06', 0),
(61, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:50:42', 0),
(62, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:51:11', 0),
(63, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:54:54', 0),
(64, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:56:05', 0),
(65, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:57:06', 0),
(66, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 06:59:44', 0),
(67, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:00:21', 0),
(68, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:00:33', 0),
(69, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:00:46', 0),
(70, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:03:06', 0),
(71, NULL, NULL, 'вот моя тема 1', 'тут моё описание ваываыва', '2019-03-30 07:05:30', 0),
(72, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:21:33', 0),
(73, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:23:52', 0),
(74, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:28:44', 0),
(75, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:31:28', 0),
(76, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:31:49', 0),
(77, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:34:11', 0),
(78, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:34:16', 0),
(79, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:34:55', 0),
(80, NULL, NULL, 'вот моя тема 1', 'тут моё описание', '2019-03-30 07:34:59', 0),
(81, NULL, NULL, 'цуйцуйцуйцу', 'йцуйцуйцуйуйцу', '2019-03-30 07:35:05', 0),
(82, NULL, NULL, 'цуйцуйцуйцу', 'йцуйцуйцуйуйцу', '2019-03-30 07:35:09', 0),
(83, NULL, NULL, 'цуйцуйцуйцу', 'йцуйцуйцуйуйцу', '2019-03-30 07:37:41', 0),
(84, NULL, NULL, 'цукцукцукцфуке', 'кеыуе56464564747', '2019-03-30 07:37:47', 0),
(85, NULL, NULL, 'цукцукцукцфуке', 'кеыуе56464564747', '2019-03-30 07:38:00', 0),
(86, NULL, NULL, 'tertertet', 'eterterte', '2019-03-30 07:46:32', 0),
(87, NULL, NULL, 'teterterte', 'tetetet', '2019-03-30 07:46:57', 0),
(88, NULL, NULL, 'tyrtyrty', 'rtyrtyrtyry', '2019-03-30 07:47:39', 0),
(89, NULL, NULL, 'ewrtwerte', 'rtetert', '2019-03-30 07:50:50', 0),
(90, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 07:58:07', 0),
(91, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 07:58:55', 0),
(92, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 07:59:10', 0),
(93, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 07:59:32', 0),
(94, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 08:00:02', 0),
(95, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 08:00:42', 0),
(96, NULL, NULL, 'куццукцк', 'куцукцк', '2019-03-30 08:04:50', 0),
(97, NULL, NULL, 'цуцкуцукцук', 'цкуцукцук', '2019-03-30 08:05:32', 0),
(98, NULL, NULL, 'цукцук', 'цукцукц', '2019-03-30 08:07:02', 0),
(99, NULL, NULL, 'цукцук', 'цукцукц', '2019-03-30 08:07:20', 0),
(100, NULL, NULL, 'еукеукеу', 'кеуеуе', '2019-03-30 08:16:39', 0),
(101, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:16:53', 0),
(102, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:16:58', 0),
(103, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:18:14', 0),
(104, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:18:16', 0),
(105, NULL, NULL, 'rwerwrwerw', 'rwerr4444444444444444444', '2019-03-30 08:18:24', 0),
(106, NULL, NULL, 'rwerwrwerw', 'rwerr4444444444444444444', '2019-03-30 08:18:26', 0),
(107, NULL, NULL, 'rwerwrwerw', 'rwerr4444444444444444444', '2019-03-30 08:18:53', 0),
(108, NULL, NULL, 'werwerwr', 'werwerw', '2019-03-30 08:18:57', 0),
(109, NULL, NULL, 'werwerwr', 'werwerw', '2019-03-30 08:18:59', 0),
(110, NULL, NULL, 'werwerwr', 'werwerw', '2019-03-30 08:52:29', 0),
(111, NULL, NULL, 'werwerwr', 'werwerw', '2019-03-30 08:53:50', 0),
(112, NULL, NULL, 'werwerwr', 'werwerw', '2019-03-30 08:54:34', 0),
(113, NULL, NULL, 'rwerwrwerw', 'rwerr4444444444444444444', '2019-03-30 08:54:38', 0),
(114, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:54:44', 0),
(115, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:55:35', 0),
(116, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:55:58', 0),
(117, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:57:38', 0),
(118, NULL, NULL, 'rtyrtyrty', 'rtyrtyrtyrtyrtyrty7777777777777777777777', '2019-03-30 08:58:54', 0),
(119, NULL, NULL, 'erewrwrew', 'erwerwrwr555555555555555555555', '2019-03-30 08:59:53', 0),
(120, NULL, NULL, 'erewrwrew', 'erwerwrwr555555555555555555555', '2019-03-30 09:06:53', 0),
(121, NULL, NULL, 'последняя запись', 'это описание последней записи', '2019-03-30 09:44:10', 0),
(122, NULL, NULL, 'последняя запись', 'это описание последней записи', '2019-03-30 09:46:14', 0),
(123, NULL, NULL, 'уцуйцуйцу', 'уцйцуйцуйцуйуйуйу', '2019-03-30 09:46:34', 0),
(124, NULL, NULL, 'ну ка', 'вот ка', '2019-03-30 09:46:56', 0),
(125, NULL, NULL, 'цуйцуйуйцуйцу', '777777777777777777', '2019-03-30 09:47:18', 0),
(126, NULL, NULL, 'уцйцуйцуцйу', '88888888888888888888888888888888', '2019-03-30 09:47:38', 0),
(127, NULL, NULL, 'йуцйцуйцуйцуйцу', 'йцуйцуйцу', '2019-03-30 09:48:33', 0),
(128, NULL, NULL, '111111111111111', '11122222222222222', '2019-03-30 09:49:55', 0),
(129, NULL, NULL, 'укукекеуке', 'укеукеуе', '2019-03-30 09:55:44', 0),
(130, NULL, NULL, 'укукекеуке', 'укеукеуе', '2019-03-30 09:56:43', 0),
(131, NULL, NULL, 'уыакцукцукцу', 'кцукцукцфуеу4еныу5ныун', '2019-03-30 09:58:10', 0),
(132, NULL, NULL, 'кцкцукцукк666666666666', '667777777777', '2019-03-30 09:59:49', 0),
(133, NULL, NULL, 'кцкцукцукк666666666666', '667777777777', '2019-03-30 10:00:05', 0),
(134, NULL, NULL, 'rtyertertert', 'erterterte46345235423423423424', '2019-03-30 10:01:59', 0),
(135, NULL, NULL, 'wrwerwrwa', 'rwarwarwarewsrware', '2019-03-30 10:05:09', 0),
(136, NULL, NULL, 'ertertertert', 'ertertert433333333333333333333', '2019-03-30 10:05:51', 0),
(137, NULL, NULL, 'tytruu', 'tyiuytiyuiyuioyouohyuoguo8', '2019-03-30 10:07:48', 0),
(138, NULL, NULL, '99999999999888888', '67567567к567687898080980', '2019-03-30 10:22:28', 0),
(139, NULL, NULL, 'гншгг', 'еншпнше', '2019-03-30 10:41:27', 0),
(141, NULL, NULL, 'erwerwerawetetse', 'rtsetsetsetsets', '2019-03-31 05:55:45', 0),
(142, NULL, NULL, 'rtewrtwerwarwar', 'awrawrawrawr', '2019-03-31 05:56:15', 0),
(143, NULL, NULL, 'ertsertsetsetsetset', 'sertsetrsetrset', '2019-03-31 05:56:38', 0),
(144, NULL, NULL, 'wqeqWERTSERTSERTSET', 'SERTSETSETSETSET', '2019-03-31 05:57:02', 0),
(145, NULL, NULL, 'rwerweertertset', '34532546464564', '2019-03-31 06:05:12', 0),
(146, NULL, NULL, 'trerterter', 'trtyrtu6756757567', '2019-03-31 06:06:20', 0),
(147, NULL, NULL, 'wewerwetreyt', 'ryrtydrtudrud', '2019-03-31 06:07:01', 0),
(148, NULL, NULL, 'wewerwetreyt', 'ryrtydrtudrud', '2019-03-31 06:14:29', 0),
(149, NULL, NULL, 'rtertertt', 'rtertert', '2019-03-31 06:14:37', 0),
(150, NULL, NULL, 'rete4ertert', 'etet345345345345345', '2019-03-31 06:49:25', 0),
(151, NULL, NULL, 'rete4ertert', 'etet345345345345345', '2019-03-31 06:49:49', 0),
(152, NULL, NULL, '6546546456e46e46', '5464564776876867868', '2019-03-31 06:49:57', 0),
(153, NULL, NULL, '6546546456e46e46', '5464564776876867868', '2019-03-31 06:50:01', 0),
(154, NULL, NULL, '6546546456e46e46', '5464564776876867868', '2019-03-31 06:50:21', 0),
(155, NULL, NULL, 'rete4ertert', 'etet345345345345345', '2019-03-31 06:50:24', 0),
(156, NULL, NULL, 'hhhhello', 'rtrtee44444444', '2019-03-31 06:50:38', 0),
(157, NULL, NULL, 'ersetett', '3333333333333333', '2019-03-31 06:51:35', 0),
(158, NULL, NULL, 'ewqweqweqwe', 'qweqweqwe', '2019-03-31 06:55:18', 0),
(159, NULL, NULL, 'ewrwerwrwe', 'rwerwerwer', '2019-03-31 06:55:38', 0),
(160, NULL, NULL, 'erwer33333333333333', '4444444444', '2019-03-31 06:56:12', 0),
(161, NULL, NULL, 'tertertet', 'rtertert', '2019-03-31 06:57:55', 0),
(162, NULL, NULL, 'rerwerwe', 'rwer3333333333333', '2019-03-31 06:58:54', 0),
(163, NULL, NULL, 'weqweqwe', 'w9999999999999999999', '2019-03-31 06:59:20', 0),
(164, NULL, NULL, '67657567567567', '6765767878678678', '2019-03-31 07:02:34', 0),
(165, NULL, NULL, '911111111192394923492349234234234', '324234234234847853475347858973457347853748573478534785783457834', '2019-03-31 07:02:54', 0),
(166, NULL, NULL, 'uiyuiyuiy', 'uiyuiyuiyuiyuiyuiyi', '2019-03-31 07:04:27', 0),
(167, NULL, NULL, 'iyuiyuiyuiyiyiyiy', '7867867867867868678678', '2019-03-31 07:04:45', 0),
(168, NULL, NULL, 'iyuiyuiyuiyiyiyiy', '7867867867867868678678', '2019-03-31 07:05:32', 0),
(169, NULL, NULL, 'rw777777777777', '777788888888888888888888', '2019-03-31 07:16:09', 0),
(170, NULL, NULL, '4ц543545', '34534535', '2019-03-31 07:21:51', 0),
(171, NULL, NULL, '4укеу5645645645', '645667568678678678969', '2019-03-31 07:22:20', 0),
(172, NULL, NULL, '666666666666666666666666', '677777777777777777777', '2019-03-31 07:22:39', 0),
(173, NULL, NULL, 'rtertertetertert', '56456457567567', '2019-04-01 11:20:40', 0),
(174, NULL, 'Андрей', 'Моя проблема с кодом', 'не могу вывести пост без ошибки в header', '2019-04-02 08:42:31', 0),
(175, NULL, 'Андрей', 'Мой последний пост от 3 Апреля', 'Отправься сим салабим', '2019-04-03 11:13:13', 0),
(176, NULL, 'Андрей', 'Мой последний пост от 3 Апреля', 'Отправься сим салабим', '2019-04-03 11:14:31', 0),
(177, NULL, 'укцукцук', 'цукцкцкц', 'кцкцкцкцку', '2019-04-03 11:14:47', 0),
(178, NULL, '756756756757', '57575', '75757576', '2019-04-03 11:15:53', 0),
(179, NULL, 'Арчи', 'Дарова братуленчик', 'КАк работа над проектами?', '2019-04-03 11:17:08', 0),
(180, NULL, 'кеукеукеу', 'еукеуке', 'укеукеукеуеку', '2019-04-06 11:46:09', 0),
(181, NULL, 'Андрей', 'Привет всем', 'мой первый пост', '2019-04-06 11:58:37', 0),
(182, NULL, 'Anonymous', 'ну ка', 'отправился?', '2019-04-09 10:44:54', 0),
(183, NULL, 'Андрей', 'hello world', 'Меня зовут омномном', '2019-04-18 08:09:51', 0),
(184, NULL, 'Андрей', 'dsadwewqr', 'rwerwerwet', '2019-07-13 08:50:36', 0),
(185, 2, 'artem', 'моя икра', 'она мне принадлежит и таким же как и я', '2019-07-13 09:20:47', 0),
(186, 18, 'medved', 'не моя икра', 'она не мне принадлежит и не таким же как и я', '2019-07-13 09:22:23', 0),
(187, 2, 'artem', 'я отдохнул', 'как я отдыхал', '2019-08-03 12:41:10', 0),
(188, 2, 'Anonymous', 'без ника', 'описание без ника', '2019-08-03 12:41:32', 0),
(189, 2, 'Арчибальд', 'измененный ник', 'оисание с изменнным ником', '2019-08-03 12:42:47', 0),
(190, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(191, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(192, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(193, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(194, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(195, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(196, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(197, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(198, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(199, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(200, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(201, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(202, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(203, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(204, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(205, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(206, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(207, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(208, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(209, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(210, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(211, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(212, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(213, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(214, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(215, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(216, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(217, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(218, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(219, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(220, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(221, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(222, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(223, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(224, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(225, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(226, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(227, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(228, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(229, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(230, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(231, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(232, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(233, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(234, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(235, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(236, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(237, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(238, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(239, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(240, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(241, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(242, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(243, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(244, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(245, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(246, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(247, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(248, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(249, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(250, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(251, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(252, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(253, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(254, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(255, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(256, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(257, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(258, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(259, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(260, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(261, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(262, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(263, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(264, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(265, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(266, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(267, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(268, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(269, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(270, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(271, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(272, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(273, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(274, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(275, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(276, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(277, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(278, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(279, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(280, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(281, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(282, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(283, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(284, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(285, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(286, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(287, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(288, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(289, NULL, NULL, 'rtrtrtrtrtrt', 'rtrtrtrtrtrt', '2019-08-12 09:43:32', 0),
(290, 2, 'artem', 'hello world', 'my opis post', '2019-08-15 05:16:29', 0),
(291, 2, 'artem', 'hello world', 'eewrwerwerwrwer', '2019-08-15 05:21:48', 0),
(292, 2, 'artem', 'hello world', 'dier friend hello my room', '2019-08-15 05:22:41', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `otvet`
--

CREATE TABLE `otvet` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL DEFAULT '0',
  `idpost` int(11) NOT NULL DEFAULT '0',
  `nameuser` varchar(100) NOT NULL,
  `opis` text,
  `vloshen` smallint(6) NOT NULL DEFAULT '0',
  `dates` datetime DEFAULT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `otvet`
--

INSERT INTO `otvet` (`id`, `iduser`, `idpost`, `nameuser`, `opis`, `vloshen`, `dates`, `del`) VALUES
(1, 2, 292, 'artem', 'лови лайкос братуленчик', 1, '2019-08-15 06:41:08', 0),
(2, 22, 292, 'artem', 'sdasdrwertererwerw', 1, '2019-08-15 06:46:33', 0),
(3, 21, 292, 'artem', 'rtdfgdgdfgdfgrertertewrw', 1, '2019-08-15 06:47:08', 0),
(4, 2, 292, 'artemgrtertterte', 'rtetertet', 1, '2019-08-15 06:47:56', 0),
(5, 2, 292, 'artemrwerwrfe', 'tertetet', 1, '2019-08-15 06:54:38', 0),
(6, 2, 291, 'artemrwerwer', 'аываваываыав', 1, '2019-08-15 07:16:22', 0),
(7, 19, 292, 'artem', 'цукцукцукпвапвап', 1, '2019-08-15 07:17:37', 0),
(8, 22, 292, 'artem', 'укцукцкцукцукпвпвап', 1, '2019-08-15 07:18:08', 0),
(9, 21, 292, 'artem', 'старая форма', 1, '2019-08-16 12:42:54', 0),
(10, 2, 292, 'artem', 'пытаюсь ответить', 1, '2019-08-17 05:37:56', 0),
(14, 19, 292, 'artem', 'hello world', 1, '2019-08-17 07:02:00', 0),
(15, 2, 292, 'artem', 'a nu ka prov', 1, '2019-08-17 07:02:51', 0),
(16, 22, 292, 'artem', 'hello world', 1, '2019-08-17 07:11:22', 0),
(17, 2, 292, 'artem', 'привет друзья', 1, '2019-08-20 07:38:46', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(70) DEFAULT NULL,
  `avatar` tinyint(4) NOT NULL DEFAULT '0',
  `login` varchar(80) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dateadd` datetime DEFAULT NULL,
  `conf` tinyint(4) NOT NULL DEFAULT '0',
  `confcod` varchar(80) DEFAULT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `avatar`, `login`, `pass`, `email`, `dateadd`, `conf`, `confcod`, `del`) VALUES
(1, 'Andrei', 5, 'ererwrwer', 'werwerwrarea', 'andrej.zimin.1094@mail.ru', '2019-06-01 03:15:11', 1, NULL, 0),
(2, 'artem', 5, 'artem', '$2y$10$CKl/YvkYt29gu/WVNq4n.OKbuNHMj7MPYaAa76cUBI2cBlSs56O3C', 'zimin@mail.ru', '2019-07-12 11:05:43', 1, '70cf0cf4bfae0f1cc9c10d57ff552524', 0),
(18, 'medved', 5, 'medved', '$2y$10$qzIgev7HOOLWFuLAKBQUNulvYzE7N1xbATr7prSguW5o1pW5DB7Uq', 'medved@mail.ru', '2019-07-12 13:57:59', 1, '01c474b11edf53f7fc3410489b44cd07', 0),
(19, 'admins', 4, 'admins', '$2y$10$aDFCYNkRc3eTkqBMRJ6h6OyLPv1n9i8hAuRG4hwau9OQFKr8yy7QC', 'admins@mail.ru', '2019-08-16 07:58:03', 1, '69085aae236d067888c2c5878cf98bda', 0),
(21, 'neadmin', 5, 'neadmin', '$2y$10$XpmEfQE5kqfVU/ytJidTx.zVvMUc1erBFAfcaRp2KBeRiXNR2VZ1.', 'neadmin@mail.ru', '2019-08-16 08:02:14', 1, '5b7402e72dada3dec88038d42df9fd26', 0),
(22, 'artem2', 2, 'artem', '12345', 'art@mail.ru', '2019-08-16 00:00:00', 1, 'ssfdszfzsfzfs', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `avatar`
--
ALTER TABLE `avatar`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kommotvet`
--
ALTER TABLE `kommotvet`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `nametheme`
--
ALTER TABLE `nametheme`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `otvet`
--
ALTER TABLE `otvet`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `avatar`
--
ALTER TABLE `avatar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `kommotvet`
--
ALTER TABLE `kommotvet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `nametheme`
--
ALTER TABLE `nametheme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=293;

--
-- AUTO_INCREMENT для таблицы `otvet`
--
ALTER TABLE `otvet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
